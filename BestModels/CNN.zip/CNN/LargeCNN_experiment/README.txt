To activate the assets in the Talos deploy package: 

   from talos.commands.restore import Restore 
   a = Restore('path_to_asset')

Now you will have an object similar to the Scan object, which can be used with other Talos commands as you would be able to with the Scan object